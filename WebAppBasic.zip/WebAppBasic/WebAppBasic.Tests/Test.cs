﻿using NUnit.Framework;
using System;

namespace WebAppBasic.Tests
{
    [TestFixture]
    public class Test
    {
        [Test]
        public void TestCase()
        {
        }
    }
}
